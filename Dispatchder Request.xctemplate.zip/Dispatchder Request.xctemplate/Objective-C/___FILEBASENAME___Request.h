//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "MTRequest.h"

@interface ___FILEBASENAMEASIDENTIFIER___Response : MTResponse

@end

@interface ___FILEBASENAMEASIDENTIFIER___Request : MTRequest

- (___FILEBASENAMEASIDENTIFIER___Response *)response;

@end
