//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___FILEBASENAME___Request.h"

@implementation ___FILEBASENAMEASIDENTIFIER___Response

- (NSError *)parseResponse:(NSHTTPURLResponse *)networkResponse data:(NSData *)responseData {
    NSError *error = [super parseResponse:networkResponse data:responseData];
    
    if (error == nil) {
        // Do object/core data model filling from protected variable _jsonDictionary
    }
    
    return error;
}

@end

@implementation ___FILEBASENAMEASIDENTIFIER___Request

- (NSMutableURLRequest *)serviceURLRequest {
    NSMutableURLRequest *request = [super serviceURLRequest];
    
    // Do any request configuration
    
    return request;
}

- (___FILEBASENAMEASIDENTIFIER___Response *)response {
    return (___FILEBASENAMEASIDENTIFIER___Response *)_response;
}

- (Class)responseClass {
    return ___FILEBASENAMEASIDENTIFIER___Response.class;
}

@end
